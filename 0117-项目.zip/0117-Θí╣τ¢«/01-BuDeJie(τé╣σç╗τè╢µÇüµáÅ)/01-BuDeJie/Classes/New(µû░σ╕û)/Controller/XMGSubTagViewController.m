//
//  XMGSubTagViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGSubTagViewController.h"
#import <AFNetworking/AFNetworking.h>
#import "XMGTagItem.h"
#import <MJExtension/MJExtension.h>
#import "XMGSubTagCell.h"
#import <SVProgressHUD/SVProgressHUD.h>

static NSString * const ID = @"cell";

@interface XMGSubTagViewController ()

/** 标签数组*/
@property (nonatomic, strong) NSArray *tags;

/** 请求会话管理者*/
@property (nonatomic, weak) AFHTTPSessionManager *mgr;

@end

@implementation XMGSubTagViewController
// 搭建界面 -> 加载数据 -> 显示出来 -> 调整细节 -> 业务逻辑
// 接口文档 -> AFN请求 -> 解析数据 -> 设计模型 -> 字典转模型 -> 模型展示到界面
// http://api.budejie.com/api/api_open.php get
// 1.圆角 2.订阅数 3.分割线全屏显示 (1.自定义分割线 2.系统自带属性,条件:8.0以上 3.重写cell的frame)
// 重写cell的frame:1.取消系统自带的分割线 2.设置tableView背景色为分割线背景色

- (void)viewDidLoad {
    [super viewDidLoad];
    
   self.title = @"推荐标签";
    
    // 1.加载数据
    [self loadNewData];
    
    // 2.注册cell
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([XMGSubTagCell class]) bundle:nil] forCellReuseIdentifier:ID];
    
    // 3.取消系统的分割线
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    // 4.设置背景色
    self.tableView.backgroundColor = XMGColor(206, 206, 206);
}

// 界面即将消失
- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    
    // 隐藏指示器
    [SVProgressHUD dismiss];
    
    // 取消所有请求数据
    [_mgr.tasks makeObjectsPerformSelector:@selector(cancel)];
    
}

// 加载数据
- (void)loadNewData
{
    // 0.提示用户当前正在加载
    [SVProgressHUD showWithStatus:@"正在加载数据..."];
    
    // 1.创建请求会话管理者
    _mgr = [AFHTTPSessionManager manager];

    // 2.拼接请求参数
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"a"] = @"tag_recommend";
    parameters[@"action"] = @"sub";
    parameters[@"c"] = @"topic";
    
    // 3.发送请求
    [_mgr GET:@"http://api.budejie.com/api/api_open.php" parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, NSArray * _Nullable responseObject) {
       
        // 字典数组 -> 模型数组
        _tags = [XMGTagItem mj_objectArrayWithKeyValuesArray:responseObject];
        
        // 刷新表格
        [self.tableView reloadData];
        
        // 隐藏指示器
        [SVProgressHUD dismiss];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        [SVProgressHUD dismiss];
    }];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _tags.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 创建cell
    XMGSubTagCell *cell = [tableView dequeueReusableCellWithIdentifier:ID];
    
    // 获取模型
    XMGTagItem *item = _tags[indexPath.row];
    
    cell.item = item;
    
    return cell;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
/*
    1.先把所有cell的位置计算出来 2.保存起来 3.等cell要显示的时候,取出对应的尺寸给cell设置
 */
@end