//
//  XMGNewViewController.h
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "XMGEssenceViewController.h"

@interface XMGNewViewController : XMGEssenceViewController

@end
