//
//  XMGSubTagCell.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGSubTagCell.h"
#import "XMGTagItem.h"
#import <UIImageView+WebCache.h>
#import "UIImage+Antialias.h"

@interface XMGSubTagCell ()
@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *nameView;
@property (weak, nonatomic) IBOutlet UILabel *numView;
@end

@implementation XMGSubTagCell
// 头像变成圆角

// 1.设置layer圆角半径
// 在iOS9之后,不用担心使用layer设置圆角,苹果已经处理,帧数都是50以上

// 2.裁剪图片
+ (instancetype)viewForXib
{
    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil][0];
}

// 重写setFrame
- (void)setFrame:(CGRect)frame
{
    frame.size.height -= 1;
    [super setFrame:frame];
    
}

- (void)setItem:(XMGTagItem *)item
{
    _item = item;
    
    // 头像
    [self.iconView xmg_setHeader:item.image_list];
    
    // 名称
    self.nameView.text = item.theme_name;
    
    // 订阅数
    NSString *str = [NSString stringWithFormat:@"%ld人订阅",item.sub_number];
    if (item.sub_number > 10000) {
        CGFloat num = item.sub_number / 10000.0;
        str = [NSString stringWithFormat:@"%.1f万人订阅",num];
    }
    self.numView.text = str;
    
}

@end
