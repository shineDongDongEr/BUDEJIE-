//
//  XMGSettingViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/4.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGSettingViewController.h"
#import <SDWebImage/SDImageCache.h>
#import "XMGFileCacheManager.h"
#import <SVProgressHUD/SVProgressHUD.h>

#define XMGCachePath NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0]
static NSString * const ID = @"cell";

@interface XMGSettingViewController ()

/** 缓存尺寸*/
@property (nonatomic, assign) NSInteger total;

@end

@implementation XMGSettingViewController

- (void)viewDidLoad {
    [super viewDidLoad];

    // 保证整个导航控制器下所有返回按钮都是一样
    // 统一设置
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithTitle:@"jump" style:0 target:self action:@selector(jump)];
 
    // 注册cell
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:ID];
    
    // 展示指示器
    [SVProgressHUD showWithStatus:@"正在计算缓存尺寸"];
    
    // 计算缓存尺寸
    [XMGFileCacheManager getDirectoryCacheSize:XMGCachePath completeBlock:^(NSInteger total) {
        
        // 隐藏指示器
        [SVProgressHUD dismiss];
        
        _total = total;
        
        // 刷新表格
        [self.tableView reloadData];
    }];
    
}

- (void)jump
{
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view.backgroundColor = [UIColor greenColor];
    
    // push谁,谁就能控制器导航条返回按钮
    // pushViewController:添加设置返回按钮功能,给push的控制器
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
   
    // 1.创建cell
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:ID forIndexPath:indexPath];

    // 2.设置缓存字符串
    cell.textLabel.text = [self getCacheStr:_total];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 清空缓存
    [XMGFileCacheManager deleteFilePath:XMGCachePath];
    
    [self.tableView reloadData];
    
}

// 获取缓存字符串,根据缓存尺寸
- (NSString *)getCacheStr:(NSInteger)cacheSize
{
    NSString *cacheStr = [NSString stringWithFormat:@"%ldB",cacheSize];
    
    if (cacheSize > 1000 * 1000) { // 1.2MB
        CGFloat cacheSizeMB = cacheSize / (1000 * 1000);
        cacheStr = [NSString stringWithFormat:@"%.1fMB",cacheSizeMB];
    } else if (cacheSize > 1000) { // KB
        CGFloat cacheSizeKB = cacheSize / 1000;
        cacheStr = [NSString stringWithFormat:@"%.1fKB",cacheSizeKB];
    }
    
   return cacheSize > 0 ?[NSString stringWithFormat:@"清楚缓存(%@)",cacheStr] : @"清楚缓存";
    
}
@end