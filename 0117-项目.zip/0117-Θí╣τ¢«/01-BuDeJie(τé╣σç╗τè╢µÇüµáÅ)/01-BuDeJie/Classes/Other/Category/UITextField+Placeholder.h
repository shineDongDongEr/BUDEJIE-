//
//  UITextField+Placeholder.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UITextField (Placeholder)

@property UIColor *placeholderColor;
- (void)xmg_setPlaceholder:(NSString *)placeholder;
@end
