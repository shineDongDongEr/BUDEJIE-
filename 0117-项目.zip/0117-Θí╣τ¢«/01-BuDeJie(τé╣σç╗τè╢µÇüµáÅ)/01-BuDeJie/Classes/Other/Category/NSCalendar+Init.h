//
//  NSCalendar+Init.h
//  日期处理
//
//  Created by 1 on 16/1/13.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSCalendar (Init)
+ (instancetype)xmg_calendar;
@end
