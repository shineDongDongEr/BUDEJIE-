//
//  main.m
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"
/*
    1.执行main
    2.执行UIApplicationMain
    2.1 创建UIApplication(设置状态栏,图标提醒数字,网络状态,打电话,发短信,打开网页)
    2.2 创建UIApplication代理:处理系统事件(应用程序生命周期,内存警告:清空缓存)
    2.3 开启主运行循环(runloop:每一线程对应一个,主线程:主要runLoop,自动开启,子线程也有runloop.必须手动开启),1.保持程序一直运行 2.处理很多事件,observe,source,time
    2.4 解析plist文件,判断下有没有指定main.storyboard,如果指定,就会去加载.
    
    加载main.stroyboard做事情:
    1.创建窗口
    2.窗口必须要有根控制器
    3.显示窗口
 */
int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
