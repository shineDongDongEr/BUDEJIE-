//
//  AppDelegate.m
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "AppDelegate.h"
#import "XMGAdViewController.h"
#import "XMGTabBarController.h"
#import "XMGTopWindow.h"

@interface AppDelegate ()

@end

@implementation AppDelegate

// 搭建框架 -> 设置tabBar内容 -> 调整tabBar内容显示 -> 设置导航条内容 -> 调整导航条显示(设置导航条标题) -> UINavigationItem(pass) -> 导航条 -> 处理导航控制器业务逻辑(跳转)
// 广告界面:什么时候进入广告,程序每次运行就会进入广告
// 广告界面实现方式: 把一个广告view添加到窗口上,只不过这个广告界面跟启动图片一样
// 广告界面不是启动界面,启动界面不能处理业务逻辑


// 启动完成就会调用AppDelegate方法
- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
 
    // 1.创建窗口(必须要强引用)
    self.window = [[UIWindow alloc] initWithFrame:[UIScreen mainScreen].bounds];
    
    // 2.设置窗口的根控制器,进入广告界面
    XMGTabBarController *tabBarVc = [[XMGTabBarController alloc] init];
    self.window.rootViewController = tabBarVc;
    
//    XMGAdViewController *adVc = [[XMGAdViewController alloc] init];
//    self.window.rootViewController = adVc;
    
    // 3.显示窗口
    // 3.1 成为应用程序的主窗口
    // 3.2 显示, hiddle = NO
    [self.window makeKeyAndVisible];
    
    // 显示顶层Window
    [XMGTopWindow sharedWindow].hidden = NO;
    [XMGTopWindow sharedWindow].clickStatusBarBlock = ^{
        UIWindow *window = [UIApplication sharedApplication].keyWindow;
        [self searchAllScrollViewsInView:window];
    };
    return YES;
}

/**
 *  查找view中的所有scrollView
 */
- (void)searchAllScrollViewsInView:(UIView *)view
{
    // 如果不在window矩形框里面，就直接返回
    // view和window没有重叠，就直接返回
    if (![view xmg_intersectWithView:nil]) return;
    
    for (UIView *subview in view.subviews) {
        [self searchAllScrollViewsInView:subview];
    }
    
    // 如果不是UIScrollView, 直接返回
    if (![view isKindOfClass:[UIScrollView class]]) return;
    
    UIScrollView *scrollView = (UIScrollView *)view;
    
    // 让scrollView滚动到最前面
    CGPoint offset = scrollView.contentOffset;
    offset.y = - scrollView.contentInset.top;
    [scrollView setContentOffset:offset animated:YES];
    
//    [scrollView scrollRectToVisible:CGRectMake(0, 0, 1, 1) animated:YES];
}

- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end
