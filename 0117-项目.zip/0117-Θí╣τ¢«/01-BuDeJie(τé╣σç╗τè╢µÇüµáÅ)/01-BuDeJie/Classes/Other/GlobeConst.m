//
//  GlobeConst.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

// restful api
// http://api.budejie.com/api/user/get
// http://api.budejie.com/api/user/add
// http://api.budejie.com/api/user/modify
// http://api.budejie.com/api/comment/add

NSString * const baseUrl = @"http://api.budejie.com/api/api_open.php";

/** App的相册名字 */
NSString * const XMGAssetCollectionTitle = @"8期-百思";

/** 全局统一的间距 */
CGFloat const XMGMargin = 10;

/** 导航栏最大的Y值 */
CGFloat const XMGNavMaxY = 64;

/** 标题栏高度 */
CGFloat const XMGTitlesH = 35;

/** Tabbar高度 */
CGFloat const XMGTabBarH = 49;