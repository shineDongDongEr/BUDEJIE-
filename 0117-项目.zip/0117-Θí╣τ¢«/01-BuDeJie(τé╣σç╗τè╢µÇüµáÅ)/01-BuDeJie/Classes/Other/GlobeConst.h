//
//  GlobeConst.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//


// 请求基本Url
UIKIT_EXTERN NSString * const baseUrl;

/** App的相册名字 */
UIKIT_EXTERN NSString * const XMGAssetCollectionTitle;

/** 全局统一的间距 */
UIKIT_EXTERN CGFloat const XMGMargin;

/** 导航栏最大的Y值 */
UIKIT_EXTERN CGFloat const XMGNavMaxY;

/** 标题栏高度 */
UIKIT_EXTERN CGFloat const XMGTitlesH;

/** Tabbar高度 */
UIKIT_EXTERN CGFloat const XMGTabBarH;
