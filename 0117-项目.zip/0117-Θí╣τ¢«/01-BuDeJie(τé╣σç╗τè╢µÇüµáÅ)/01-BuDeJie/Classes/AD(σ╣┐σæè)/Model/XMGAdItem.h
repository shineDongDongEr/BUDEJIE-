//
//  XMGAdItem.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/4.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>
// w_picurl: w:图片宽度 h:图片高度 ori_curl:点击广告图片,进入界面
@interface XMGAdItem : NSObject

/** 广告图片*/
@property (nonatomic, strong) NSString *w_picurl;

// 点击广告图片,进入界面
@property (nonatomic, strong) NSString *ori_curl;

@property (nonatomic, assign) CGFloat w;

@property (nonatomic, assign) CGFloat h;

@end
