//
//  XMGAdViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/4.
//  Copyright © 2016年 小码哥. All rights reserved.
//

// 在线json解析器:http://json.cn

/*      完整的url = 基本url + 参数(?后面:参数)
      基本URLhttp://mobads.baidu.com/cpro/ui/mads.php ?code2=phcqnauGuHYkFMRquANhmgN_IauBThfqmgKsUARhIWdGULPxnz3vndtkQW08nau_I1Y1P1Rhmhwz5Hb8nBuL5HDknWRhTA_qmvqVQhGGUhI_py4MQhF1TvChmgKY5H6hmyPW5RFRHzuET1dGULnhuAN85HchUy7s5HDhIywGujY3P1n3mWb1PvDLnvF-Pyf4mHR4nyRvmWPBmhwBPjcLPyfsPHT3uWm4FMPLpHYkFh7sTA-b5yRzPj6sPvRdFhPdTWYsFMKzuykEmyfqnauGuAu95Rnsnbfknbm1QHnkwW6VPjujnBdKfWD1QHnsnbRsnHwKfYwAwiu9mLfqHbD_H70hTv6qnHn1PauVmynqnjclnj0lnj0lnj0lnj0lnj0hThYqniuVujYkFhkC5HRvnB3dFh7spyfqnW0srj64nBu9TjYsFMub5HDhTZFEujdzTLK_mgPCFMP85Rnsnbfknbm1QHnkwW6VPjujnBdKfWD1QHnsnbRsnHwKfYwAwiuBnHfdnjD4rjnvPWYkFh7sTZu-TWY1QW68nBuWUHYdnHchIAYqPHDzFhqsmyPGIZbqniuYThuYTjd1uAVxnz3vnzu9IjYzFh6qP1RsFMws5y-fpAq8uHT_nBuYmycqnau1IjYkPjRsnHb3n1mvnHDkQWD4niuVmybqniu1uy3qwD-HQDFKHakHHNn_HR7fQ7uDQ7PcHzkHiR3_RYqNQD7jfzkPiRn_wdKHQDP5HikPfRb_fNc_NbwPQDdRHzkDiNchTvwW5HnvPj0zQWndnHRvnBsdPWb4ri3kPW0kPHmhmLnqPH6LP1ndm1-WPyDvnHKBrAw9nju9PHIhmH9WmH6zrjRhTv7_5iu85HDhTvd15HDhTLTqP1RsFh4ETjYYPW0sPzuVuyYqn1mYnjc8nWbvrjTdQjRvrHb4QWDvnjDdPBuk5yRzPj6sPvRdgvPsTBu_my4bTvP9TARqnam
 */

// 获取接口步骤: 1.尝试用网页去获取数据. 2.如果能获取数据,表示接口没问题 3.使用AFN加载请求 4.解析请求数据 5.字典转模型 6.把模型数据展示到界面上

#import "XMGAdViewController.h"
#import <AFNetworking/AFNetworking.h>
#import "XMGAdItem.h"
#import <MJExtension/MJExtension.h>
#import <UIImageView+WebCache.h>
#import "XMGTabBarController.h"

// 定义code2参数值
static NSString * const code2 = @"phcqnauGuHYkFMRquANhmgN_IauBThfqmgKsUARhIWdGULPxnz3vndtkQW08nau_I1Y1P1Rhmhwz5Hb8nBuL5HDknWRhTA_qmvqVQhGGUhI_py4MQhF1TvChmgKY5H6hmyPW5RFRHzuET1dGULnhuAN85HchUy7s5HDhIywGujY3P1n3mWb1PvDLnvF-Pyf4mHR4nyRvmWPBmhwBPjcLPyfsPHT3uWm4FMPLpHYkFh7sTA-b5yRzPj6sPvRdFhPdTWYsFMKzuykEmyfqnauGuAu95Rnsnbfknbm1QHnkwW6VPjujnBdKfWD1QHnsnbRsnHwKfYwAwiu9mLfqHbD_H70hTv6qnHn1PauVmynqnjclnj0lnj0lnj0lnj0lnj0hThYqniuVujYkFhkC5HRvnB3dFh7spyfqnW0srj64nBu9TjYsFMub5HDhTZFEujdzTLK_mgPCFMP85Rnsnbfknbm1QHnkwW6VPjujnBdKfWD1QHnsnbRsnHwKfYwAwiuBnHfdnjD4rjnvPWYkFh7sTZu-TWY1QW68nBuWUHYdnHchIAYqPHDzFhqsmyPGIZbqniuYThuYTjd1uAVxnz3vnzu9IjYzFh6qP1RsFMws5y-fpAq8uHT_nBuYmycqnau1IjYkPjRsnHb3n1mvnHDkQWD4niuVmybqniu1uy3qwD-HQDFKHakHHNn_HR7fQ7uDQ7PcHzkHiR3_RYqNQD7jfzkPiRn_wdKHQDP5HikPfRb_fNc_NbwPQDdRHzkDiNchTvwW5HnvPj0zQWndnHRvnBsdPWb4ri3kPW0kPHmhmLnqPH6LP1ndm1-WPyDvnHKBrAw9nju9PHIhmH9WmH6zrjRhTv7_5iu85HDhTvd15HDhTLTqP1RsFh4ETjYYPW0sPzuVuyYqn1mYnjc8nWbvrjTdQjRvrHb4QWDvnjDdPBuk5yRzPj6sPvRdgvPsTBu_my4bTvP9TARqnam";

@interface XMGAdViewController ()
/** 启动view*/
@property (weak, nonatomic) IBOutlet UIImageView *launchView;
/** 广告view*/
@property (weak, nonatomic) IBOutlet UIView *adView;
/** 广告模型*/
@property (nonatomic, strong) XMGAdItem *item;
/** 跳转按钮*/
@property (weak, nonatomic) IBOutlet UIButton *jumpButton;

/** 定时器*/
@property (nonatomic, weak) NSTimer *timer;
@end

@implementation XMGAdViewController

#pragma mark - 生命周期方法
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    // 1.设置启动图片
    [self setupLaunchImage];
    
    // 2.加载广告界面
    [self loadAdData];
    
    // 添加定时器
    _timer = [NSTimer scheduledTimerWithTimeInterval:1 target:self selector:@selector(timeChange) userInfo:nil repeats:YES];
    
}

#pragma mark - 1.设置启动图片
- (void)setupLaunchImage
{
    // 判断下屏幕尺寸
    // 480:LaunchImage-700 568:LaunchImage-700-568
    // 667:LaunchImage-800-667h 736:LaunchImage-800-Portrait-736h
    if (iPhone4) { // iPhone4
        XMGLog(@"iPhone4");
        _launchView.image = [UIImage imageNamed:@"LaunchImage-700"];
    } else if (iPhone5) {
        _launchView.image = [UIImage imageNamed:@"LaunchImage-700-568h"];
    } else if (iPhone6) {
        _launchView.image = [UIImage imageNamed:@"LaunchImage-800-667h"];
    } else if (iPhone6p) {
        _launchView.image = [UIImage imageNamed:@"LaunchImage-800-Portrait-736h"];
    }
    
}

#pragma mark - 加载广告界面
- (void)loadAdData
{
    // 1.创建请求会话管理者
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
    
    // 2.拼接请求参数
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"code2"] = code2;
    
    // 3.发送请求,先把数据写成plist
    [mgr GET:@"http://mobads.baidu.com/cpro/ui/mads.php" parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * _Nullable responseObject) {
        
        // 1.解析返回数据
        NSDictionary *dict = [responseObject[@"ad"] firstObject];
        
        // 2.字典转模型
        _item =  [XMGAdItem mj_objectWithKeyValues:dict];
        
        // 3.计算图片显示高度
        CGFloat imageH = XMGScreenW / _item.w * _item.h;
        
        // 4.显示广告界面
        UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, XMGScreenW, imageH)];
        imageView.userInteractionEnabled = YES;
        [imageView sd_setImageWithURL:[NSURL URLWithString:_item.w_picurl]];
        [self.adView addSubview:imageView];
        
        // 5.添加点按手势
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tap)];
        [imageView addGestureRecognizer:tap];
        
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        NSLog(@"%@",error);
    }];
    
}

#pragma mark - 定时器
// 每隔一秒调用
- (void)timeChange{
    
    // 定义广告时间
    static int time = 3;
    
    // 时间到了,跳转
    if (time == 0) {
        [self jumpMain:nil];
    }
    
    // 时间减少
    time--;
    
    // 设置跳转按钮标题
    [_jumpButton setTitle:[NSString stringWithFormat:@" 跳过(%d) ",time] forState:UIControlStateNormal];
    
}

#pragma mark - 点击事件处理
// 点击跳过,进入主框架界面,modal,更换窗口的根控制器
- (IBAction)jumpMain:(id)sender {
    // 创建主框架
    XMGTabBarController *tabBarVc = [[XMGTabBarController alloc] init];
    
    [UIApplication sharedApplication].keyWindow.rootViewController = tabBarVc;
    
    // 销毁定时器
    [_timer invalidate];
    
}


// 点击广告界面调用
- (void)tap
{
    NSURL *url = [NSURL URLWithString:_item.ori_curl];
    if ([[UIApplication sharedApplication] canOpenURL:url]) {
        
        // 跳转到对应界面,展示网址
        [[UIApplication sharedApplication] openURL:url];
    }
}


@end
