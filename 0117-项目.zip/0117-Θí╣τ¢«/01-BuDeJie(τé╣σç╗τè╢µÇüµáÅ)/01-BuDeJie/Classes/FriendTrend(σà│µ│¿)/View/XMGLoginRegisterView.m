//
//  XMGLoginRegisterView.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGLoginRegisterView.h"


@interface XMGLoginRegisterView ()

@property (weak, nonatomic) IBOutlet UIButton *loginButton;

@end

@implementation XMGLoginRegisterView
- (void)awakeFromNib
{
    UIImage *image = _loginButton.currentBackgroundImage;
    image = [image stretchableImageWithLeftCapWidth:image.size.width * 0.5 topCapHeight:image.size.height * 0.5];
    [_loginButton setBackgroundImage:image forState:UIControlStateNormal];
    
    // 拉伸高亮
    UIImage *highImage = [_loginButton backgroundImageForState:UIControlStateHighlighted];
    highImage = [highImage stretchableImageWithLeftCapWidth:highImage.size.width * 0.5 topCapHeight:image.size.height * 0.5];
    [_loginButton setBackgroundImage:highImage forState:UIControlStateHighlighted];
}

+ (instancetype)loginViewForXib
{
    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil][0];
}

+ (instancetype)registerViewForXib
{
    return [[NSBundle mainBundle] loadNibNamed:NSStringFromClass(self) owner:nil options:nil][1];
}

@end
