//
//  XMGInputTextField.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

/*
 解决:
 1.修改光标
 2.修改占位文字颜色
 
 在哪个方法做事情 -init awakeFromNib
 */

#import "XMGInputTextField.h"
#import "UITextField+Placeholder.h"

// 思想: 获取占位文字lable控件,猜测有可能是UITextField某个属性,1.用runtime遍历所有属性,看下能否拿到lable控件 2.断点调试

@implementation XMGInputTextField

// 当对象从xib加载完成就会调用
- (void)awakeFromNib
{
    // 1.设置光标
    self.tintColor = [UIColor whiteColor];
    
    // 初始化占位文字颜色
    self.placeholderColor = [UIColor lightGrayColor];
    
    // 监听文本框:1.代理(🙅) 2.addtarget 3.通知
   // 封装自己类,做好不要自己成为自己的代理,导致别人使用不好使.
    // 监听开始编辑
    [self addTarget:self action:@selector(textBegin) forControlEvents:UIControlEventEditingDidBegin];
    
    // 监听结束编辑
     [self addTarget:self action:@selector(textEnd) forControlEvents:UIControlEventEditingDidEnd];
}

// 文本框开始编辑:监听文本框什么时候开始编辑
- (void)textBegin
{
    self.placeholderColor = [UIColor whiteColor];
}

- (void)textEnd
{
    self.placeholderColor = [UIColor lightGrayColor];
}

@end
