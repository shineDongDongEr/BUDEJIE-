//
//  XMGFastLoginButton.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGFastLoginButton.h"

@implementation XMGFastLoginButton
- (void)layoutSubviews
{
    [super layoutSubviews];
    
    // 调整图片
    self.imageView.xmg_x = (self.xmg_width - self.imageView.xmg_width) * 0.5;
    self.imageView.xmg_y = 0;
    
    // 调整文字
    // 计算文字尺寸,设置文字宽度
    [self.titleLabel sizeToFit];
    self.titleLabel.xmg_x =(self.xmg_width - self.titleLabel.xmg_width) * 0.5;
    self.titleLabel.xmg_y = self.xmg_height - self.titleLabel.xmg_height;
    
}

@end
