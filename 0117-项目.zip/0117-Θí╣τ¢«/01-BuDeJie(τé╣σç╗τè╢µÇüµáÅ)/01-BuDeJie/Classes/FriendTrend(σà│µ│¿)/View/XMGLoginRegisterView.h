//
//  XMGLoginRegisterView.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum : NSUInteger {
    XMGLoginType,
    XMGRegisterType,
} XMGLoginRegisterViewType;

@interface XMGLoginRegisterView : UIView
+ (instancetype)loginViewForXib;
+ (instancetype)registerViewForXib;
@end
