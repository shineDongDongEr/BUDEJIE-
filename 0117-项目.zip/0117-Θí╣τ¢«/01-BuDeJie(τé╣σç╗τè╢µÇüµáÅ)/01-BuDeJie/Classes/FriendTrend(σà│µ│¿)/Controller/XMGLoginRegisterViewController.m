//
//  XMGLoginRegisterViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGLoginRegisterViewController.h"
#import "XMGLoginRegisterView.h"
#import "XMGFastLoginView.h"
/*
    1. 分析分几个结构,上中下
    2.占位视图
    3.一个一个结构去做
 */
@interface XMGLoginRegisterViewController ()
@property (weak, nonatomic) IBOutlet UIView *middleView;
@property (weak, nonatomic) IBOutlet UIView *bottomView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *middleViewConsL;
@end

@implementation XMGLoginRegisterViewController

#pragma mark - 点击业务逻辑
// 点击关闭就会调用
- (IBAction)close:(id)sender {
    [self dismissViewControllerAnimated:YES completion:nil];
}

// 点击注册按钮就会调用
- (IBAction)clickRegister:(UIButton *)sender {
    sender.selected = !sender.selected;
    
    // 移动中间view
    _middleViewConsL.constant = _middleViewConsL.constant?0:- XMGScreenW;
    
    [UIView animateWithDuration:0.25 animations:^{
        // 让父控件重新布局
        [self.view layoutIfNeeded];
    }];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 创建子控件
    // Do any additional setup after loading the view from its nib.
    // 添加登录输入框,默认一个view从xib加载,view的尺寸根xib一样
    XMGLoginRegisterView *loginView = [XMGLoginRegisterView loginViewForXib];
    
    [self.middleView addSubview:loginView];
    
    // 添加注册输入框
    XMGLoginRegisterView *registerView = [XMGLoginRegisterView registerViewForXib];
   
    [self.middleView addSubview:registerView];
    
    // 添加快速登录view
    XMGFastLoginView *fastView = [XMGFastLoginView fastViewForXib];
    [self.bottomView addSubview:fastView];
}

// 给控制器的子控件位置赋值
- (void)viewDidLayoutSubviews
{
    // 才会真正执行xib描述约束
    [super viewDidLayoutSubviews];
    
    // 登录
    UIView *loginV = self.middleView.subviews[0];
    // 使用Xib,xib中关心好子控件约束,自己控件尺寸有外界决定.
    // 必须要设置frame
    loginV.frame = CGRectMake(0, 0, self.middleView.xmg_width * 0.5, self.middleView.xmg_height);

    // 注册
    UIView *registerV = self.middleView.subviews[1];
    // 设置frame
    registerV.frame = CGRectMake(self.middleView.xmg_width * 0.5, 0, self.middleView.xmg_width * 0.5, self.middleView.xmg_height);

    // 快速登录viewframe
    UIView *fastV = self.bottomView.subviews[0];
    fastV.frame = CGRectMake(0, 0, self.bottomView.xmg_width, self.bottomView.xmg_height);
    
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    [self.view endEditing:YES];
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return UIStatusBarStyleLightContent;
}

@end
