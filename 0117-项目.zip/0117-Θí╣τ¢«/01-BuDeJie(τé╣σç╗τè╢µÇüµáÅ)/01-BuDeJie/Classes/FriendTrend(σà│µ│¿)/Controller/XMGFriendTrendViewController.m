//
//  XMGFriendTrendViewController.m
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "XMGFriendTrendViewController.h"
#import "XMGLoginRegisterViewController.h"
#import "UIColor+Hex.h"
#import "UITextField+Placeholder.h"

@interface XMGFriendTrendViewController ()
@property (weak, nonatomic) IBOutlet UITextField *texfField;
@end

@implementation XMGFriendTrendViewController

#pragma mark - 生命周期方法
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置导航条
    [self setupNavBar];
    
    // 设置占位文字颜色
    // 把属性保存到系统的类里面,runtime
    _texfField.placeholderColor = [UIColor greenColor];
    // 1.把你占位文字颜色保存起来
    // 2.等设置占位文字,在重新设置下
    
    // 设置texfField占位文字
    // setPlaceholder:系统,需要给系统的方法添加额外功能,runtime
    // 1.自己实现一个带有这个功能的方法
    // 2.把系统方法实现跟自己方法交互
    _texfField.placeholder = @"123";
}

// 设置导航条
- (void)setupNavBar
{
    // UINavigationItem:决定导航条内容
    // UIBarButtonItem:决定导航条上按钮的内容
    
    // left
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithImage:[UIImage imageNamed:@"friendsRecommentIcon"] highImage:[UIImage imageNamed:@"friendsRecommentIcon-click"] target:self action:@selector(clickRecomment)];
    
    // title
    self.navigationItem.title = @"我的关注";
}

#pragma mark - 点击事件
// 点击登陆注册按钮调用
- (IBAction)loginRegister {
    XMGLoginRegisterViewController *loginVc = [[XMGLoginRegisterViewController alloc] init];
    
    // 跳转到登陆注册界面modal
    [self presentViewController:loginVc animated:YES completion:nil];
}

// 点击推荐就会调用
- (void)clickRecomment
{
    
}

@end
