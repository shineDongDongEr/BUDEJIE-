//
//  XMGFileCacheManager.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMGFileCacheManager : NSObject

/**
 *  获取文件夹尺寸
 *
 *  @param directoryPath 文件夹路径
 *  @param completeBlock 计算完成回调block
 *  @return 文件夹尺寸
 */
+ (void)getDirectoryCacheSize:(NSString *)directoryPath completeBlock:(void(^)(NSInteger total))completeBlock;

/**
 *  获取文件尺寸
 *
 *  @param filePath 文件路径
 *
 *  @return 文件尺寸
 */
+ (NSInteger)getFileCacheSize:(NSString *)filePath;

/**
 *  删除文件缓存
 *
 *  @param filePath 文件路径
 */
+ (void)deleteFilePath:(NSString *)filePath;

@end
