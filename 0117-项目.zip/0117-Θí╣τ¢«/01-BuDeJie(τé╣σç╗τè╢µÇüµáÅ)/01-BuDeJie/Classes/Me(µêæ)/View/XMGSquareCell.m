//
//  XMGSquareCell.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGSquareCell.h"
#import <UIImageView+WebCache.h>
#import "XMGSquareItem.h"

@interface XMGSquareCell ()

@property (weak, nonatomic) IBOutlet UIImageView *iconView;
@property (weak, nonatomic) IBOutlet UILabel *nameView;


@end

@implementation XMGSquareCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setItem:(XMGSquareItem *)item
{
    _item = item;
    
    // 设置头像
    [_iconView sd_setImageWithURL:[NSURL URLWithString:item.icon]];
    
    // 设置名称
    _nameView.text = item.name;
    
}

@end
