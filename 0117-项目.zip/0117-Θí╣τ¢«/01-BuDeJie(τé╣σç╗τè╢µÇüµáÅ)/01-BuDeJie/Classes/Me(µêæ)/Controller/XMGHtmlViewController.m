//
//  XMGHtmlViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGHtmlViewController.h"
#import <WebKit/WebKit.h>

@interface XMGHtmlViewController ()
@property (weak, nonatomic) IBOutlet UIView *ContentView;
@property (weak, nonatomic) WKWebView *webView;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *backItem;
@property (weak, nonatomic) IBOutlet UIBarButtonItem *forwardItem;
@property (nonatomic, weak) UIProgressView *progressView;
@end

@implementation XMGHtmlViewController

/*
    展示网页:
    1.safari:自带很多功能(进度条,网址,刷新,回退,前进),不足:必须要离开当前应用.
    2.UIWebView:展示网页,没有任何功能,好处:在当前应用下打开网页.
    3.在之前,如果想要在当前应用下有safari功能,只能自定义UIWebView,但是有个功能做不了,进度条,UIWebView没有提供这个属性,获取网站加载进度
    4.SFSafariViewController:有safari所有功能,而且在当前应用展示,弊端:不能做适配,只能在iOS9才能使用
    5.展开网页,而且有safari功能(进度条),WKWebView(WKWebKit),监听网页进度,网页缓存
    注意:WebKit需要手动导入
 
    图标引擎:图片资源
 */

#pragma mark - 生命周期方法
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    // 添加WKWebView
    WKWebView *webView = [[WKWebView alloc] init];
    [_ContentView addSubview:webView];
    _webView = webView;
    
    // 加载网页
    NSURLRequest *request = [NSURLRequest requestWithURL:_url];
    [webView loadRequest:request];
    
    // 添加进度条
    [self setupProgress];
    
    // KVO监听属性
    // 监听canGoBack
    [webView addObserver:self forKeyPath:@"canGoBack" options:NSKeyValueObservingOptionNew context:nil];
    // 监听canGoForward
    [webView addObserver:self forKeyPath:@"canGoForward" options:NSKeyValueObservingOptionNew context:nil];
    // 监听estimatedProgress
    [webView addObserver:self forKeyPath:@"estimatedProgress" options:NSKeyValueObservingOptionNew context:nil];
    // URL
    [webView addObserver:self forKeyPath:@"URL" options:NSKeyValueObservingOptionNew context:nil];
    // title
    [webView addObserver:self forKeyPath:@"title" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)viewDidLayoutSubviews
{
    [super viewDidLayoutSubviews];
    
    _webView.frame = self.ContentView.bounds;
}

#pragma mark - 添加子控件
// 添加进度条
- (void)setupProgress
{
    UIProgressView *progressView = [[UIProgressView alloc] initWithFrame:CGRectMake(0, 64, XMGScreenW, 2)];
    progressView.progressTintColor = [UIColor greenColor];
    _progressView = progressView;
    [self.view addSubview:progressView];
}

#pragma mark - 工具条业务逻辑
// 倒退
- (IBAction)back:(id)sender {
    [_webView goBack];
}

// 前进
- (IBAction)forward:(id)sender {
    [_webView goForward];
}

// 刷新
- (IBAction)refresh:(id)sender {
    [_webView reload];
}

#pragma mark - KVO方法
// 监听对象属性改变就会调用,监听webView的canGoBack
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    _backItem.enabled = _webView.canGoBack;
    _forwardItem.enabled = _webView.canGoForward;
    _progressView.progress = _webView.estimatedProgress;
    // 进度条 >= 1 隐藏
    _progressView.hidden = _progressView.progress >= 1;
    self.title = _webView.title;
   
}

// KVO:一定要记得移除观察者
- (void)dealloc
{
    [_webView removeObserver:self forKeyPath:@"canGoBack"];
    [_webView removeObserver:self forKeyPath:@"canGoForward"];
    [_webView removeObserver:self forKeyPath:@"estimatedProgress"];
    [_webView removeObserver:self forKeyPath:@"URL"];
    [_webView removeObserver:self forKeyPath:@"title"];

}

@end
