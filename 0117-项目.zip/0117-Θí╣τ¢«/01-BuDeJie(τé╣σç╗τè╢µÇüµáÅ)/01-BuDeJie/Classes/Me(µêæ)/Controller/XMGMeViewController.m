//
//  XMGMeViewController.m
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//



#import "XMGMeViewController.h"
#import "XMGSettingViewController.h"
#import "XMGSquareCell.h"
#import <AFNetworking/AFNetworking.h>
#import <MJExtension/MJExtension.h>
#import "XMGSquareItem.h"
#import "XMGHtmlViewController.h"
#import <SafariServices/SafariServices.h>

static NSString * const ID = @"cell";
static CGFloat const margin = 1;
static NSInteger const cols = 4;
#define cellWH ((XMGScreenW - (cols - 1) * margin) / cols)

@interface XMGMeViewController ()<UICollectionViewDataSource,UICollectionViewDelegate>
/** 方块模型数组*/
@property (nonatomic, strong) NSMutableArray *squareList;
@property (nonatomic, strong) UICollectionView *collectionView;
@end

@implementation XMGMeViewController
// 搭建我的界面 -> 请求数据 -> 把数据展示到界面 -> 调整界面细节 -> 业务逻辑处理,方块点击
// 静态单元格 -> storyboard
#pragma mark - 生命周期方法
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 设置导航条
    [self setupNavBar];
    
    // 设置footView
    [self setupFootView];
    
    // 请求数据
    [self loadData];
    
    // 处理cell间距,默认tablewView分组样式,每一组都有间距
    self.tableView.sectionFooterHeight = XMGMargin;
    self.tableView.sectionHeaderHeight = 0;
    self.tableView.contentInset = UIEdgeInsetsMake(XMGMargin - 35, 0, 0, 0);
    
    // 注意:tableView额外滚动区域,在之前的基础上相加.
}

#pragma mark - 加载数据
// 请求数据 -> 接口文档 -> AFN -> 解析数据,写成plist -> 设计模型 -> 字典模型
- (void)loadData
{
    // 1.创建请求会话管理者
    AFHTTPSessionManager *mgr = [AFHTTPSessionManager manager];
    
    // 2.拼接请求参数
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"a"] = @"square";
    parameters[@"c"] = @"topic";
    
    // 3.发送请求
    [mgr GET:baseUrl parameters:parameters success:^(NSURLSessionDataTask * _Nonnull task, NSDictionary * _Nullable responseObject) {
        
        // 字典数组转模型数组
       _squareList = [XMGSquareItem mj_objectArrayWithKeyValuesArray:responseObject[@"square_list"]];
        
        // 处理数据
        [self resolveData];
        
        // 刷新表格
        [self.collectionView reloadData];
        
        // 计算collectionView高度 -> rows行数 = (总数 - 1) / cols + 1
        NSInteger count = _squareList.count;
        NSInteger rows = (count - 1) / cols + 1;
        CGFloat  collectionViewH = rows * cellWH;
        _collectionView.xmg_height = collectionViewH;
        
        // 设置tableView滚动范围
//        self.tableView.contentSize = CGSizeMake(0, CGRectGetMaxY(_collectionView.frame));
        // tableView的滚动范围自己管理,只需要给他指定内容,会自动计算自己的滚动范围.
        // 设置tableView底部视图
        self.tableView.tableFooterView = _collectionView;
        
        // 刷新表格(重新计算contentSize)
        [self.tableView reloadData];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        
    }];
}

// 处理数据
- (void)resolveData
{
    // 判断下还差几个
    // 3 % 4 = 3 extre: 4 - 3 = 1
    NSUInteger count = self.squareList.count;
    
    NSInteger extre = count % cols;
    
    if (extre) {
        extre = cols - extre;
        for (int i = 0; i < extre; i++) {
            XMGSquareItem *item = [[XMGSquareItem alloc] init];
            [self.squareList addObject:item];
        }
    }
}

#pragma mark - 搭建界面方法
// 设置footView
- (void)setupFootView
{
    // 流水布局
    UICollectionViewFlowLayout *layout = [[UICollectionViewFlowLayout alloc] init];
    
    // 设置cell尺寸
    layout.itemSize = CGSizeMake(cellWH, cellWH);
    // 设置cell间距
    layout.minimumInteritemSpacing = margin;
    layout.minimumLineSpacing = margin;
 
    // 创建UICollectionView
    UICollectionView *collectionView = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, 0, 0) collectionViewLayout:layout];
    collectionView.backgroundColor = self.tableView.backgroundColor;
    collectionView.dataSource = self;
    // 监听cell点击
    collectionView.delegate = self;
    _collectionView = collectionView;
    
    // 设置footView
    self.tableView.tableFooterView = collectionView;

    // 注册cell
    [collectionView registerNib:[UINib nibWithNibName:NSStringFromClass([XMGSquareCell class]) bundle:nil] forCellWithReuseIdentifier:ID];
    
    // 不允许collectionView滚动
    collectionView.scrollEnabled = NO;
 
}

// 设置导航条
- (void)setupNavBar
{
    // UINavigationItem:决定导航条内容
    // UIBarButtonItem:决定导航条上按钮的内容
    
    // 设置
    UIBarButtonItem *settintItem = [UIBarButtonItem itemWithImage:[UIImage imageNamed:@"mine-setting-icon"] highImage:[UIImage imageNamed:@"mine-setting-icon-click"] target:self action:@selector(clickSetting)];
    
    // 夜间
    UIBarButtonItem *nightItem = [UIBarButtonItem itemWithImage:[UIImage imageNamed:@"mine-moon-icon"] selImage:[UIImage imageNamed:@"mine-moon-icon-click"] target:self action:@selector(clickNight:)];
    
    // right
    self.navigationItem.rightBarButtonItems = @[settintItem,nightItem];

    // title
    self.navigationItem.title = @"我的";
    
}

#pragma mark - 界面业务逻辑方法
// 点击设置就会调用
- (void)clickSetting
{
    // 跳转设置界面
    XMGSettingViewController *settingVc = [[XMGSettingViewController alloc] init];
 
    [self.navigationController pushViewController:settingVc animated:YES];
}

// 进入夜间模式
- (void)clickNight:(UIButton *)btn
{
    btn.selected = !btn.selected;
}

#pragma mark - UICollectionViewDataSource
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.squareList.count;
}

- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    // 创建cell
    XMGSquareCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:ID forIndexPath:indexPath];
    
    XMGSquareItem *item = self.squareList[indexPath.row];
    
    cell.item = item;
    
    return cell;
}

#pragma mark - UICollectionViewDelegate
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
{
    
    // 获取模型
    XMGSquareItem *item = self.squareList[indexPath.row];
    
    if ([item.url hasPrefix:@"http"]) {
        // 自定义展示网页控制器
        XMGHtmlViewController *htmlVc = [[XMGHtmlViewController alloc] init];
        htmlVc.url = [NSURL URLWithString:item.url];
        
        // 跳转到网页
        [self.navigationController pushViewController:htmlVc animated:YES];

    }
    
}

@end