//
//  XMGSquareItem.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/7.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMGSquareItem : NSObject

/** 名称*/
@property (nonatomic, strong) NSString *name;

/** 图片*/
@property (nonatomic, strong) NSString *icon;

/** url*/
@property (nonatomic, strong) NSString *url;

@end
