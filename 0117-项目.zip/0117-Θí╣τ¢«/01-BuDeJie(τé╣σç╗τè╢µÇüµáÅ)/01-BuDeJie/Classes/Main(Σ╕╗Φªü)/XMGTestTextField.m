//
//  XMGTestTextField.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/16.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGTestTextField.h"

@implementation XMGTestTextField

- (CGRect)placeholderRectForBounds:(CGRect)bounds
{
    return CGRectMake(0, 0, 100, 100);
}

- (CGRect)clearButtonRectForBounds:(CGRect)bounds
{
    return CGRectMake(0, 0, 10, 10);
}

@end
