//
//  XMGNavigationController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/4.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGNavigationController.h"

// 开发习惯:自定义完一个类,就想到马上使用

@interface XMGNavigationController ()<UIGestureRecognizerDelegate>

@end

@implementation XMGNavigationController

+ (void)load
{
    // 获取当前导航控制器下的导航条
    UINavigationBar *navBar = [UINavigationBar appearanceWhenContainedIn:self, nil];
    
    // 设置导航条标题 -> 由导航条决定
    NSMutableDictionary *attr = [NSMutableDictionary dictionary];
    attr[NSFontAttributeName] = [UIFont boldSystemFontOfSize:20];
    navBar.titleTextAttributes = attr;
    
    // 统一设置导航条背景图片 - > UIBarMetricsDefault,其他的模式都不好使.
    [navBar setBackgroundImage:[UIImage imageNamed:@"navigationbarBackgroundWhite"] forBarMetrics:UIBarMetricsDefault];

}

/*  UIPanGestureRecognizer:整个view
    导航控制器的滑动手势:UIScreenEdgePanGestureRecognizer
    target: <_UINavigationInteractiveTransition 0x7f9589d733c0>)
    action = handleNavigationTransition:
 */
- (void)viewDidLoad {
    [super viewDidLoad];

    // 全屏滑动:添加一个pan手势,全屏滑动返回
    UIPanGestureRecognizer *pan = [[UIPanGestureRecognizer alloc] initWithTarget:self.interactivePopGestureRecognizer.delegate action:@selector(handleNavigationTransition:)];
    pan.delegate = self;
    [self.view addGestureRecognizer:pan];

    // 禁止边缘滑动手势
    self.interactivePopGestureRecognizer.enabled = NO;
}

// 重写系统方法:
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    // 非根控制器才需要设置
    if (self.childViewControllers.count) {
        // 只要把系统返回按钮覆盖,就不会再有滑动返回功能
        // 不但要设置返回按钮,并且还要恢复滑动返回功能
        // 覆盖了返回按钮,滑动手势并没有被干掉,只是失效,代理做了事情
        // 隐藏底部条
        viewController.hidesBottomBarWhenPushed = YES;
        
        // 设置返回按钮
        viewController.navigationItem.leftBarButtonItem = [UIBarButtonItem backItemWithImage:[UIImage imageNamed:@"navigationButtonReturn"] highImage:[UIImage imageNamed:@"navigationButtonReturnClick"] target:self action:@selector(back) title:@"返回"];
    }
    
    // 这里才是真正跳转
    [super pushViewController:viewController animated:animated];
}

- (void)back
{
    [self popViewControllerAnimated:YES];
}

#pragma mark - UIGestureRecognizerDelegate
// 是否触发手势
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    // 非根控制器才需要触发手势
    return self.childViewControllers.count > 1;
}

@end
