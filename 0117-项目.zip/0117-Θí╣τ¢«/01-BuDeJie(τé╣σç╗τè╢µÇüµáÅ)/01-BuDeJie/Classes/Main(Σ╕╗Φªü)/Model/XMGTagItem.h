//
//  XMGTagItem.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/5.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface XMGTagItem : NSObject

/** 头像*/
@property (nonatomic, strong) NSString *image_list;
/** 订阅数*/
@property (nonatomic, assign) NSInteger sub_number;
/** 名称*/
@property (nonatomic, strong) NSString *theme_name;

@end
