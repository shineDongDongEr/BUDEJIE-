//
//  XMGHTTPSessionManager.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/16.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGHTTPSessionManager.h"

@implementation XMGHTTPSessionManager

- (instancetype)initWithBaseURL:(NSURL *)url
           sessionConfiguration:(NSURLSessionConfiguration *)configuration
{
    if (self = [super initWithBaseURL:url sessionConfiguration:configuration]) {
//        self.requestSerializer = ...;
//        self.responseSerializer = ...;
//        self.securityPolicy = ...;
    }
    return self;
}

@end
