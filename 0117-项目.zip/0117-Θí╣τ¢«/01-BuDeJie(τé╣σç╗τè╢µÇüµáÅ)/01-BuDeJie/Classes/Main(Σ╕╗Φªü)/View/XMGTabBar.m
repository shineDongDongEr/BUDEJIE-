//
//  XMGTabBar.m
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "XMGTabBar.h"
#import "UIView+Frame.h"
@interface XMGTabBar ()
/** 加号按钮 */
@property (nonatomic, weak) UIButton *plusButton;
@end

@implementation XMGTabBar

- (UIButton *)plusButton
{
    if (!_plusButton) {
        UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
        [btn setImage:[UIImage imageNamed:@"tabBar_publish_icon"] forState:UIControlStateNormal];
        [btn setImage:[UIImage imageNamed:@"tabBar_publish_click_icon"] forState:UIControlStateHighlighted];
        // 自动根据图片或者文字计算控件的尺寸
        [btn sizeToFit];
        _plusButton = btn;
        [self addSubview:btn];
    }
    return _plusButton;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat btnW = self.xmg_width / (self.items.count + 1);
    CGFloat btnH = self.xmg_height;
    CGFloat btnX = 0;
    CGFloat btnY = 0;
    // 调整子控件位置 UITabBarButton
    int i = 0;
    for (UIView *tabBarButton in self.subviews) {
        if ([tabBarButton isKindOfClass:NSClassFromString(@"UITabBarButton")]) {
            
            if (i == 2) {
                i += 1;
            }
            
            btnX = i * btnW;
            
            // 调整子控件位置
            tabBarButton.frame = CGRectMake(btnX, btnY, btnW, btnH);
            
            i++;
        }
    }
    
    // 调整加号按钮位置
    self.plusButton.center = CGPointMake(self.bounds.size.width * 0.5, self.bounds.size.height * 0.5);
}

@end
