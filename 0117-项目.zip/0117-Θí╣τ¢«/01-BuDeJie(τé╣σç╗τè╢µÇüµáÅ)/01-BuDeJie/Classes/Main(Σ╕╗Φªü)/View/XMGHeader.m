//
//  XMGHeader.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/16.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGHeader.h"

@interface XMGHeader()
/** logo */
@property (nonatomic, weak) UIImageView *logoView;
@end

@implementation XMGHeader

/**
 *  初始化
 */
- (void)prepare
{
    [super prepare];
    
    // 自动改变透明度
    self.automaticallyChangeAlpha = YES;
    // 隐藏时间
    self.lastUpdatedTimeLabel.hidden = YES;
    // 修改状态文字颜色
    self.stateLabel.textColor = [UIColor redColor];
    // 设置不同状态下的文字
    [self setTitle:@"下拉吧" forState:MJRefreshStateIdle];
    [self setTitle:@"松开🐴上刷新" forState:MJRefreshStatePulling];
    [self setTitle:@"正在拼命加载数据..." forState:MJRefreshStateRefreshing];
    
    // 添加LOGO
    UIImageView *logoView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"MainTitle"]];
    [self addSubview:logoView];
    self.logoView = logoView;
}

/**
 *  布局子控件
 */
- (void)placeSubviews
{
    [super placeSubviews];
    
    self.logoView.xmg_y = - self.logoView.xmg_height;
    self.logoView.xmg_centerX = self.xmg_width * 0.5;
}

//- (void)layoutSubviews
//{
//    [super layoutSubviews];
//    
//
//}

@end
