//
//  XMGFooter.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/16.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <MJRefresh/MJRefresh.h>

@interface XMGFooter : MJRefreshAutoNormalFooter

@end
