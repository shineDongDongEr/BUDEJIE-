//
//  XMGTopWindow.h
//  点击状态栏区域
//
//  Created by 1 on 16/1/17.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

#pragma mark - 顶层window的根控制器
/****** 顶层window的根控制器 ******/
@interface XMGTopViewController : UIViewController

@end

#pragma mark - 顶层window
/****** 顶层window ******/
@interface XMGTopWindow : UIWindow
//+ (void)show;

+ (instancetype)sharedWindow;

/** 这个block会在点击状态栏的时候调用 */
@property (nonatomic, copy) void (^clickStatusBarBlock)();

/** 控制状态栏的显示\隐藏 */
@property (nonatomic, assign, getter=isStatusBarHidden) BOOL statusBarHidden;

/** 控制状态栏的样式 */
@property (nonatomic, assign) UIStatusBarStyle statusBarStyle;
@end
