//
//  XMGTopWindow.m
//  点击状态栏区域
//
//  Created by 1 on 16/1/17.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGTopWindow.h"

#pragma mark - 顶层window的根控制器
/****** 顶层window的根控制器 ******/
@implementation XMGTopViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.view.backgroundColor = [UIColor clearColor];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    void (^block)() = [XMGTopWindow sharedWindow].clickStatusBarBlock;
    !block ? : block();
    
    //    if (block) {
    //        block();
    //    }
}

#pragma mark - 状态栏
- (BOOL)prefersStatusBarHidden
{
    return [XMGTopWindow sharedWindow].statusBarHidden;
}

- (UIStatusBarStyle)preferredStatusBarStyle
{
    return [XMGTopWindow sharedWindow].statusBarStyle;
}
@end

#pragma mark - 顶层window
/****** 顶层window ******/
@interface XMGTopWindow() <NSCopying>
@end

@implementation XMGTopWindow

- (void)setStatusBarStyle:(UIStatusBarStyle)style
{
    _statusBarStyle = style;
    
    // 刷新状态栏(会重新调用控制器的prefersStatusBarHidden和preferredStatusBarStyle方法)
    [self.rootViewController setNeedsStatusBarAppearanceUpdate];
}

- (void)setStatusBarHidden:(BOOL)hidden
{
    _statusBarHidden = hidden;
    
    // 刷新状态栏(会重新调用控制器的prefersStatusBarHidden和preferredStatusBarStyle方法)
    [self.rootViewController setNeedsStatusBarAppearanceUpdate];
}

#pragma mark - 事件处理
- (UIView *)hitTest:(CGPoint)point withEvent:(UIEvent *)event
{
    // 触摸点的y > 20，就不处理
    if (point.y > 20) return nil;
    
    return [super hitTest:point withEvent:event];
}

#pragma mark - 初始化
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.statusBarStyle = UIStatusBarStyleDefault;
        self.statusBarHidden = NO;
        self.windowLevel = UIWindowLevelAlert;
        self.rootViewController = [[XMGTopViewController alloc] init];
    }
    return self;
}

/**
 *  保证window的背景色永远是clearColor
 */
- (void)setBackgroundColor:(UIColor *)backgroundColor
{
    [super setBackgroundColor:[UIColor clearColor]];
}

#pragma mark - 单例模式
static XMGTopWindow *instance_;

+ (instancetype)allocWithZone:(struct _NSZone *)zone
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance_ = [super allocWithZone:zone];
    });
    return instance_;
}

+ (instancetype)sharedWindow
{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        instance_ = [[self alloc] init];
    });
    return instance_;
}

#pragma mark - <NSCopying>
- (id)copyWithZone:(NSZone *)zone
{
    return instance_;
}

//static UIWindow *topWindow_;
//+ (void)show
//{
//    topWindow_ = [[XMGTopWindow alloc] init];
//    topWindow_.frame = [UIApplication sharedApplication].statusBarFrame;
//    topWindow_.backgroundColor = [UIColor redColor];
//    topWindow_.hidden = NO;
//    topWindow_.windowLevel = UIWindowLevelAlert;
//    topWindow_.rootViewController = [[XMGTopViewController alloc] init];
//}

@end
