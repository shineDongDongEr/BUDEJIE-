//
//  XMGTopic.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/9.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGTopic.h"

@implementation XMGTopic

- (CGFloat)cellHeight
{
    if (_cellHeight) return _cellHeight;
    
    // 根据模型数据计算出cell的高度
    // 头像
    _cellHeight += 55;
    
    // 文字
    CGFloat textMaxW = [UIScreen mainScreen].bounds.size.width - 2 * XMGMargin;
    _cellHeight += [self.text boundingRectWithSize:CGSizeMake(textMaxW, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:15]} context:nil].size.height + XMGMargin;
    
    // 中间(图片\声音\视频)
    if (self.type != XMGTopicTypeWord) {
        CGFloat centerW = textMaxW;
        CGFloat centerH = centerW * self.height / self.width;
        CGFloat centerY = _cellHeight;
        CGFloat centerX = XMGMargin;
        
        if (centerH >= XMGScreenH) { // 中间的内容超过一个屏幕
            centerH = 200;
            self.bigPicture = YES;
        }
        self.centerF = CGRectMake(centerX, centerY, centerW, centerH);
        
        _cellHeight += centerH + XMGMargin;
    }
    
    // 最热评论
    if (self.top_cmt.count) {
        // 标题
        _cellHeight += 20;
        
        // 内容
        NSDictionary *dict = self.top_cmt.firstObject;
        NSString *username = dict[@"user"][@"username"];
        NSString *content = dict[@"content"];
        NSString *cmt = [NSString stringWithFormat:@"%@ : %@", username, content];
        _cellHeight += [cmt boundingRectWithSize:CGSizeMake(textMaxW, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName : [UIFont systemFontOfSize:14]} context:nil].size.height + XMGMargin;
    }
    
    // 工具条
    _cellHeight += 35 + XMGMargin;
    return _cellHeight;
}

@end
