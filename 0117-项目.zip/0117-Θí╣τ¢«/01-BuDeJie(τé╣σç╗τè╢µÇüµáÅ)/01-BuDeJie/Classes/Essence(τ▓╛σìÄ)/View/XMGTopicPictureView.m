//
//  XMGTopicPictureView.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/15.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGTopicPictureView.h"
#import "XMGTopic.h"
#import "XMGSeeBigPictureViewController.h"

@interface XMGTopicPictureView()
@property (weak, nonatomic) IBOutlet UIImageView *gifView;
@property (weak, nonatomic) IBOutlet UIButton *seeBigPictureButton;
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@end

@implementation XMGTopicPictureView
#pragma mark - 监听点击
- (void)seeBigPicture
{
    XMGSeeBigPictureViewController *vc = [[XMGSeeBigPictureViewController alloc] init];
    vc.topic = self.topic;
    [self.window.rootViewController presentViewController:vc animated:YES completion:nil];
}

#pragma mark - 初始化
- (void)awakeFromNib
{
    self.imageView.userInteractionEnabled = YES;
    [self.imageView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(seeBigPicture)]];
    
    self.autoresizingMask = UIViewAutoresizingNone;
}

- (void)setTopic:(XMGTopic *)topic
{
    _topic = topic;
    
    // 图片
    [self.imageView xmg_setOriginImage:topic.image1 smallImage:topic.image0 placeholder:nil];
    
    // gif
    self.gifView.hidden = !topic.is_gif;
    
    // 点击查看大图按钮
    if (topic.isBigPicture) { // 超长图片
        self.imageView.contentMode = UIViewContentModeTop;
        self.clipsToBounds = YES; // 超出imageView边框的内容会被剪掉
        self.seeBigPictureButton.hidden = NO;
    } else {
        self.imageView.contentMode = UIViewContentModeScaleToFill;
        self.seeBigPictureButton.hidden = YES;
        self.clipsToBounds = NO;
    }
}
@end
