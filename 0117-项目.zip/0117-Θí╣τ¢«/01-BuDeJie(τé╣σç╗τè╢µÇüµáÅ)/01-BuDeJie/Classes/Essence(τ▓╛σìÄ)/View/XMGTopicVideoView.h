//
//  XMGTopicVideoView.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/15.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMGTopic;

@interface XMGTopicVideoView : UIView
/** 帖子模型 */
@property (nonatomic, strong) XMGTopic *topic;
@end
