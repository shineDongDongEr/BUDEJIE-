//
//  XMGTopicVideoView.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/15.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGTopicVideoView.h"
#import "XMGTopic.h"
#import "XMGSeeBigPictureViewController.h"

@interface XMGTopicVideoView()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UILabel *playCountLabel;
@property (weak, nonatomic) IBOutlet UILabel *videoTimeLabel;
@end

@implementation XMGTopicVideoView
#pragma mark - 监听点击
- (void)seeBigPicture
{
    XMGSeeBigPictureViewController *vc = [[XMGSeeBigPictureViewController alloc] init];
    vc.topic = self.topic;
    [self.window.rootViewController presentViewController:vc animated:YES completion:nil];
}

#pragma mark - 初始化
- (void)awakeFromNib
{
    self.imageView.userInteractionEnabled = YES;
    [self.imageView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(seeBigPicture)]];
    
    self.autoresizingMask = UIViewAutoresizingNone;
}

- (void)setTopic:(XMGTopic *)topic
{
    _topic = topic;
    
    // 图片
    [self.imageView xmg_setOriginImage:topic.image1 smallImage:topic.image0 placeholder:nil];
    
    // 播放数量
    if (topic.playcount >= 10000) {
        self.playCountLabel.text = [NSString stringWithFormat:@"%.1f万播放", topic.playcount / 10000.0];
    } else {
        self.playCountLabel.text = [NSString stringWithFormat:@"%zd播放", topic.playcount];
    }
    
    // 时长
    NSInteger minute = topic.videotime / 60;
    NSInteger second = topic.videotime % 60;
    // %04zd : 这个整数占据4位, 多余的位用0填补
    self.videoTimeLabel.text = [NSString stringWithFormat:@"%02zd:%02zd", minute, second];
}

@end
