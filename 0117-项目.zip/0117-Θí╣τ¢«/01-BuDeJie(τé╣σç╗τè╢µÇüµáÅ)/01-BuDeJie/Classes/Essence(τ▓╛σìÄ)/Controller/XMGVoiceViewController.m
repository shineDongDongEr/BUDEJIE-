//
//  XMGVoiceViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/8.
//  Copyright © 2016年 小码哥. Voice rights reserved.
//

#import "XMGVoiceViewController.h"

@implementation XMGVoiceViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
 
    [self.view addSubview:[[UISwitch alloc] init]];
}

- (XMGTopicType)type
{
    return XMGTopicTypeVoice;
}
@end
