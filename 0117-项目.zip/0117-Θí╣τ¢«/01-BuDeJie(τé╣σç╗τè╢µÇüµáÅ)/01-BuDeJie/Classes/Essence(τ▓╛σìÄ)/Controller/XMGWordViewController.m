//
//  XMGWordViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/8.
//  Copyright © 2016年 小码哥. Word rights reserved.
//

#import "XMGWordViewController.h"

@implementation XMGWordViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (XMGTopicType)type
{
    return XMGTopicTypeWord;
}
@end
