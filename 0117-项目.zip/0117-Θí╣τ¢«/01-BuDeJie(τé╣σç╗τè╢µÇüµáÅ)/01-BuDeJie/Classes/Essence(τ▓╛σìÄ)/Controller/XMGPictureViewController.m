//
//  XMGPictureViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/8.
//  Copyright © 2016年 小码哥. Picture rights reserved.
//

#import "XMGPictureViewController.h"

@implementation XMGPictureViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (XMGTopicType)type
{
    return XMGTopicTypePicture;
}
@end
