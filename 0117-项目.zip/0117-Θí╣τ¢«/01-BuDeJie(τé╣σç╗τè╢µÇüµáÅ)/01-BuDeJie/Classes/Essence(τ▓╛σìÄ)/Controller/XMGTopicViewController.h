//
//  XMGTopicViewController.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/16.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "XMGTopic.h"

@interface XMGTopicViewController : UITableViewController

/** 类型 */
//@property (nonatomic, assign) XMGTopicType type;
//@property (nonatomic, assign, readonly) XMGTopicType type;

- (XMGTopicType)type;

@end
