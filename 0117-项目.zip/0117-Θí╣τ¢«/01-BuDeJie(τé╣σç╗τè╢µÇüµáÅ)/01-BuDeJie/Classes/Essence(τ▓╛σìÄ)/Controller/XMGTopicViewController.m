//
//  XMGTopicViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/8.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGTopicViewController.h"
#import "XMGHTTPSessionManager.h"
#import "XMGTopic.h"
#import <MJExtension.h>
#import "XMGTopicCell.h"
#import <UIImageView+WebCache.h>
#import "XMGHeader.h"
#import "XMGFooter.h"
#import "XMGNewViewController.h"

@interface XMGTopicViewController ()
/** 发送请求的管理者 */
@property (nonatomic, strong) XMGHTTPSessionManager *manager;
/** 所有的XMGTopic帖子数据 */
@property (nonatomic, strong) NSMutableArray *topics;
/** 用来加载下一页数据的 */
@property (nonatomic, copy) NSString *maxtime;
@end

@implementation XMGTopicViewController

- (XMGTopicType)type {return 0;}

static NSString * const XMGTopicCellId = @"topic";

/**
 *  mgr懒加载方法
 */
- (XMGHTTPSessionManager *)manager
{
    if (!_manager) {
        _manager = [XMGHTTPSessionManager manager];
    }
    return _manager;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 处理表格
    [self setupTable];
    
    // 添加刷新控件
    [self setupRefresh];
}

/**
 *  处理表格
 */
- (void)setupTable
{
    self.tableView.backgroundColor = XMGColor(200, 200, 200);
    self.tableView.contentInset = UIEdgeInsetsMake(XMGNavMaxY + XMGTitlesH, 0, XMGTabBarH, 0);
    self.tableView.scrollIndicatorInsets = self.tableView.contentInset;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    // 注册cell(register方法会自动给创建好的cell绑定ReuseIdentifier)
    [self.tableView registerNib:[UINib nibWithNibName:NSStringFromClass([XMGTopicCell class]) bundle:nil] forCellReuseIdentifier:XMGTopicCellId];
}

/**
 *  添加刷新控件
 */
- (void)setupRefresh
{
    // 下拉 - 加载最新的数据
    self.tableView.mj_header = [XMGHeader headerWithRefreshingTarget:self refreshingAction:@selector(loadNewTopics)];
    [self.tableView.mj_header beginRefreshing];
    
    // 上拉 - 加载更多的数据
    self.tableView.mj_footer = [XMGFooter footerWithRefreshingTarget:self refreshingAction:@selector(loadMoreTopics)];
}

#pragma mark - 数据处理
/**
 *  a参数
 */
- (NSString *)a
{
    if ([self.parentViewController isKindOfClass:[XMGNewViewController class]]) return @"newlist";
    
    return @"list";
}

/**
 *  加载最新的帖子数据
 */
- (void)loadNewTopics
{
    // 取消任务
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    
    // 拼接请求参数
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"a"] = self.a;
    parameters[@"type"] = @(self.type);
    parameters[@"c"] = @"data";
    
    // 发送请求
    [self.manager GET:baseUrl parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) {
        // 存储maxtime, 用来加载下一页数据
        self.maxtime = responseObject[@"info"][@"maxtime"];
        
        // 字典数组 -> XMGTopic模型数组
        self.topics = [XMGTopic mj_objectArrayWithKeyValuesArray:responseObject[@"list"]];
        
        // 刷新表格
        [self.tableView reloadData];
        
        // 结束刷新
        [self.tableView.mj_header endRefreshing];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        // 一个任务被取消了, 也会来到failure这个block, 并且error.code是NSURLErrorCancelled
        
        // 结束刷新
        [self.tableView.mj_header endRefreshing];
    }];
}

/**
 *  加载更多的帖子数据
 */
- (void)loadMoreTopics
{
    // 取消任务
    [self.manager.tasks makeObjectsPerformSelector:@selector(cancel)];
    
    // 拼接请求参数
    NSMutableDictionary *parameters = [NSMutableDictionary dictionary];
    parameters[@"a"] = self.a;
    parameters[@"type"] = @(self.type);
    parameters[@"c"] = @"data";
    parameters[@"maxtime"] = self.maxtime;
    
    // 发送请求
    [self.manager GET:baseUrl parameters:parameters progress:nil success:^(NSURLSessionDataTask * _Nonnull task, id _Nullable responseObject) {
        // 存储maxtime, 用来加载下一页数据
        self.maxtime = responseObject[@"info"][@"maxtime"];
        
        // 字典数组 -> XMGTopic模型数组
        NSArray *moreTopics = [XMGTopic mj_objectArrayWithKeyValuesArray:responseObject[@"list"]];
        [self.topics addObjectsFromArray:moreTopics];
        
        // 刷新表格
        [self.tableView reloadData];
        
        // 结束刷新
        [self.tableView.mj_footer endRefreshing];
    } failure:^(NSURLSessionDataTask * _Nullable task, NSError * _Nonnull error) {
        // 结束刷新
        [self.tableView.mj_footer endRefreshing];
    }];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    self.tableView.mj_footer.hidden = (self.topics.count == 0);
    
    return self.topics.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    XMGTopicCell *cell = [tableView dequeueReusableCellWithIdentifier:XMGTopicCellId];
    
    cell.topic = self.topics[indexPath.row];
    
    return cell;
}

#pragma mark - 代理方法
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 模型数据
    XMGTopic *topic = self.topics[indexPath.row];
    return topic.cellHeight;
}

/**
 * 只要scrollView在滚动, 这个方法就会调用
 */
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    // 每当scrollView滚动, 就清除内存缓存
    [[SDImageCache sharedImageCache] clearMemory];
}
@end
