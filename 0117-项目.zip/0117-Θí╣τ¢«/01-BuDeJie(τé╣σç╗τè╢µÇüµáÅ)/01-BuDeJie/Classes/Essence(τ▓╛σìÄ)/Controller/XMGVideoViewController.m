//
//  XMGVideoViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/8.
//  Copyright © 2016年 小码哥. Video rights reserved.
//

#import "XMGVideoViewController.h"

@implementation XMGVideoViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    
}

- (XMGTopicType)type
{
    return XMGTopicTypeVideo;
}
@end
