//
//  XMGSeeBigPictureViewController.m
//  01-BuDeJie
//
//  Created by 1 on 16/1/15.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGSeeBigPictureViewController.h"
#import <UIImageView+WebCache.h>
#import "XMGTopic.h"
#import <SVProgressHUD.h>
#import <Photos/Photos.h>

@interface XMGSeeBigPictureViewController () <UIScrollViewDelegate>
@property (nonatomic, weak) UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UIButton *saveButton;

/** 相册 */
@property (nonatomic, strong) PHAssetCollection *assetCollection;

- (PHFetchResult *)assets;
@end

@implementation XMGSeeBigPictureViewController
#pragma mark - 初始化
/**
 * 控制器的view刚加载完毕就会调用这个方法
 * 如果控制器的view是通过xib加载的, 那么在viewDidLoad方法中, 控制器view的尺寸就是xib中view的尺寸
 */
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // scrollView
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.frame = [UIScreen mainScreen].bounds;
    [scrollView addGestureRecognizer:[[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(back)]];
    [self.view insertSubview:scrollView atIndex:0];
    
    // imageView
    UIImageView *imageView = [[UIImageView alloc] init];
    [imageView sd_setImageWithURL:[NSURL URLWithString:self.topic.image1] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
        if (image == nil) return;
        
        self.saveButton.enabled = YES;
    }];
    [scrollView addSubview:imageView];
    self.imageView = imageView;
    
    // imageView - frame
    CGFloat imageW = XMGScreenW;
    CGFloat imageH = imageW * self.topic.height / self.topic.width;
    CGFloat imageY = 0;
    if (imageH < XMGScreenH) { // 图片高度不够
        imageY = (XMGScreenH - imageH) * 0.5;
    } else { // 图片高度 超过 一个屏幕
        scrollView.contentSize = CGSizeMake(0, imageH);
    }
    imageView.frame = CGRectMake(0, imageY, imageW, imageH);
    
    // scrollView缩放比例
    CGFloat scale = self.topic.height / imageH;
    if (scale > 1.0) {
        scrollView.maximumZoomScale = scale;
        scrollView.delegate = self;
    }
}

#pragma mark - 代理方法
- (UIView *)viewForZoomingInScrollView:(UIScrollView *)scrollView
{
    return self.imageView;
}

#pragma mark - 监听点击
- (IBAction)back {
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (IBAction)save {
    // 判断用户对【当前应用访问相册】的授权状态
    PHAuthorizationStatus status = [PHPhotoLibrary authorizationStatus];
    switch (status) {
        case PHAuthorizationStatusNotDetermined: {
            // 主动弹框请求授权
            [PHPhotoLibrary requestAuthorization:^(PHAuthorizationStatus justNowStatus) {
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (justNowStatus == PHAuthorizationStatusDenied) {
                        // 用户刚才点击了【Dont't Allow】\【不允许】按钮
                    } else if (justNowStatus == PHAuthorizationStatusAuthorized) {
                        // 用户刚才点击了【OK】\【好】按钮
                        [self saveImage];
                    }
                });
            }];
            break;
        }
            
        case PHAuthorizationStatusRestricted: {
            [SVProgressHUD showErrorWithStatus:@"因为系统原因，无法保存图片"];
            break;
        }
            
        case PHAuthorizationStatusDenied: {
            // 提示用户：【设置】-【隐私】-【照片】-【百思不得姐8】
            break;
        }
            
        case PHAuthorizationStatusAuthorized: {
            [self saveImage];
            break;
        }
    }
}
#pragma mark - 懒加载
/**
 *  获得当前App的相册
 */
- (PHAssetCollection *)assetCollection
{
    if (!_assetCollection) {
        // type : PHAssetCollectionTypeAlbum
        // subtype : PHAssetCollectionSubtypeAlbumRegular
        // 获得所有的自定义相册
        PHFetchResult<PHAssetCollection *> *assetCollections = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
        for (PHAssetCollection *ac in assetCollections) {
            if ([ac.localizedTitle isEqualToString:XMGAssetCollectionTitle]) {
                return _assetCollection = ac;
            }
        }
        
        // 创建新的相册
        __block NSString *assetCollectionId = nil;
        [[PHPhotoLibrary sharedPhotoLibrary] performChangesAndWait:^{
            assetCollectionId = [PHAssetCollectionChangeRequest creationRequestForAssetCollectionWithTitle:XMGAssetCollectionTitle].placeholderForCreatedAssetCollection.localIdentifier;
        } error:nil];
        
        // 获得刚才创建好的新相册
        return _assetCollection = [PHAssetCollection fetchAssetCollectionsWithLocalIdentifiers:@[assetCollectionId] options:nil].firstObject;
    }
    return _assetCollection;
}

#pragma mark - 相册处理
/**
 *  返回添加到相机胶卷中的图片
 */
- (PHFetchResult *)assets
{
    __block NSString *assetId = nil;
    
    [[PHPhotoLibrary sharedPhotoLibrary] performChangesAndWait:^{
        // 添加图片到【Camera Roll(相机胶卷)】
        assetId = [PHAssetChangeRequest creationRequestForAssetFromImage:self.imageView.image].placeholderForCreatedAsset.localIdentifier;
    } error:nil];
    
    return [PHAsset fetchAssetsWithLocalIdentifiers:@[assetId] options:nil];
}

/**
 *  保存图片到自定义相册
 */
- (void)saveImage
{
    NSError *error = nil;
    
    // 相册
    PHAssetCollection *assetCollection = self.assetCollection;
    
    // 图片
    PHFetchResult *assets = self.assets;
    
    // 将刚才添加到【Camera Roll(相机胶卷)】中的图片, 顺便添加到【自定义相册】
    [[PHPhotoLibrary sharedPhotoLibrary] performChangesAndWait:^{
        PHAssetCollectionChangeRequest *request = [PHAssetCollectionChangeRequest changeRequestForAssetCollection:assetCollection];
        [request insertAssets:assets atIndexes:[NSIndexSet indexSetWithIndex:0]];
    } error:&error];
    
    // 错误判断
    if (error) {
        [SVProgressHUD showErrorWithStatus:@"保存失败！"];
    } else {
        [SVProgressHUD showSuccessWithStatus:@"保存成功！"];
    }
}

//- (void)saveImage
//{
//    __block NSString *assetCollectionId = nil;
//    __block NSString *assetId = nil;
//    
//    // 获得已经创建好的相册
//    __block PHAssetCollection *assetCollection = nil;
//    // type : PHAssetCollectionTypeAlbum
//    // subtype : PHAssetCollectionSubtypeAlbumRegular
//    PHFetchResult<PHAssetCollection *> *assetCollections = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeAlbum subtype:PHAssetCollectionSubtypeAlbumRegular options:nil];
//    for (PHAssetCollection *ac in assetCollections) {
//        if ([ac.localizedTitle isEqualToString:XMGAssetCollectionTitle]) {
//            assetCollection = ac;
//            break;
//        }
//    }
//    
//    // 基本变量
//    PHPhotoLibrary *library = [PHPhotoLibrary sharedPhotoLibrary];
//    NSError *error = nil;
//    
//    // 执行修改
//    [library performChangesAndWait:^{
//        // 添加图片到【Camera Roll(相机胶卷)】
//        assetId = [PHAssetChangeRequest creationRequestForAssetFromImage:self.imageView.image].placeholderForCreatedAsset.localIdentifier;
//        
//        // 创建【自定义相册】
//        if (assetCollection == nil) {
//            assetCollectionId = [PHAssetCollectionChangeRequest creationRequestForAssetCollectionWithTitle:XMGAssetCollectionTitle].placeholderForCreatedAssetCollection.localIdentifier;
//        }
//    } error:&error];
//    
//    if (assetCollection == nil) {
//        // 根据已创建相册的唯一标识去获得相册
//        assetCollection = [PHAssetCollection fetchAssetCollectionsWithLocalIdentifiers:@[assetCollectionId] options:nil].firstObject;
//    }
//    
//    // 执行修改
//    [library performChangesAndWait:^{
//        // 将刚才添加到【Camera Roll(相机胶卷)】中的图片, 顺便添加到【自定义相册】
//        PHAssetCollectionChangeRequest *request = [PHAssetCollectionChangeRequest changeRequestForAssetCollection:assetCollection];
//        
//        PHFetchResult *assets = [PHAsset fetchAssetsWithLocalIdentifiers:@[assetCollectionId] options:nil];
//        [request addAssets:assets];
//    } error:&error];
//    
//    // 错误判断
//    if (error) {
//        [SVProgressHUD showErrorWithStatus:@"保存失败！"];
//    } else {
//        [SVProgressHUD showSuccessWithStatus:@"保存成功！"];
//    }
//}

/**
 *  获取相机胶卷相册
 */
- (void)getCameraRoll
{
    // type : PHAssetCollectionTypeSmartAlbum
    // subtype : PHAssetCollectionSubtypeSmartAlbumUserLibrary
    PHAssetCollection *cameraRoll = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeSmartAlbumUserLibrary options:nil].firstObject;
    
//    PHFetchResult<PHAssetCollection *> *assetCollections = [PHAssetCollection fetchAssetCollectionsWithType:PHAssetCollectionTypeSmartAlbum subtype:PHAssetCollectionSubtypeSmartAlbumUserLibrary options:nil];
//    for (PHAssetCollection *ac in assetCollections) {
//        XMGLog(@"%@", ac.localizedTitle)
//    }
}

//- (void)saveImage
//{
//    [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
//        // 添加图片到【Camera Roll(相机胶卷)】
//        
//        // 创建【自定义相册】
//    } completionHandler:^(BOOL success, NSError * _Nullable error) {
//        
//        [[PHPhotoLibrary sharedPhotoLibrary] performChanges:^{
//            // 将刚才保存到【Camera Roll(相机胶卷)】中的图片, 添加到【自定义相册】
//        } completionHandler:^(BOOL success, NSError * _Nullable error) {
//            
//        }];
//    }];
//}
@end
