//
//  XMGPictureViewController.h
//  01-BuDeJie
//
//  Created by 1 on 16/1/8.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGTopicViewController.h"

@interface XMGPictureViewController : XMGTopicViewController

@end
