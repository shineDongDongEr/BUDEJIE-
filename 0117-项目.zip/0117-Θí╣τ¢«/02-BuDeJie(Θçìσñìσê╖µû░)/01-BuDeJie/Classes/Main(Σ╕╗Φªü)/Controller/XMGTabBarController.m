//
//  XMGTabBarController.m
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "XMGTabBarController.h"
#import "XMGEssenceViewController.h"
#import "XMGNewViewController.h"
#import "XMGPublishViewController.h"
#import "XMGFriendTrendViewController.h"
#import "XMGMeViewController.h"
#import "UIImage+Image.h"
#import "XMGTabBar.h"
#import "XMGNavigationController.h"

#define XMGTabBarButtonTitleFont [UIFont systemFontOfSize:13]

@interface XMGTabBarController ()

@end

@implementation XMGTabBarController

// 当前加载内存的时候就会调用,只会调用一次
+ (void)load
{
    // 获取当前类中的所有tabBarItem
    UITabBarItem *item = [UITabBarItem appearanceWhenContainedIn:self, nil];
    
    // 1.设置默认状态下的标题字体
    // 1.1描述字符串的属性
    NSMutableDictionary *attrNor = [NSMutableDictionary dictionary];
    // 1.2设置标题字体大小
    attrNor[NSFontAttributeName] = XMGTabBarButtonTitleFont;
    [item setTitleTextAttributes:attrNor forState:UIControlStateNormal];
    
    // 2.设置tabBarButton按钮选中标题颜色
    // 2.1 描述字符串的属性
    NSMutableDictionary *attrSel = [NSMutableDictionary dictionary];
    // 2.2 设置字体颜色
    attrSel[NSForegroundColorAttributeName] = [UIColor blackColor];
    // 设置选中状态下的标题颜色
    [item setTitleTextAttributes:attrSel forState:UIControlStateSelected];
    
}

#pragma mark - 控制器view生命周期方法
- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 1 给tabBarVc添加所有子控制器(每一个子控制器对应一个按钮,几个按钮就几个控制器)
    [self setupAllChildViewController];
    // 2 设置tabBar上所有按钮内容:UITabBarButton上按钮内容由对应子控制器的tabBarItem决定
    [self setupAllTabBarButton];
    
    // self.tabbar = XMGTabBar
    // 3 自定义tabBar,把系统的tabBar换成自己的tabBar,目的:需要系统tabBarButton添加到我自己的tabBar
    // 必须放在添加系统tabBarButton之前
    [self setupTabBar];
}

- (void)setupTabBar
{
    // 创建XMGTabBar
    XMGTabBar *tabBar = [[XMGTabBar alloc] initWithFrame:self.tabBar.frame];
    
    // 设置XMGTabBarController
    [self setValue:tabBar forKey:@"tabBar"];
    
    // readonly可以使用KVC,KVC首先去看有没有set方法,找成员属性
//    self.tabBar = tabBar;
    
    // UITabBarController所管理UITabBar的delegate就是UITabBarController
    
    // UITabBarController所管理UITabBar的delegate是不允许修改的
    // Changing the delegate of a tab bar managed by a tab bar controller is not allowed.
}

#pragma mark - 二.设置所有tabBarButton内容
- (void)setupAllTabBarButton
{
    // 插件按照路径:前往 -> 资源库 -> Application Support -> Developer
    // 思考:插件安装到什么地方?
    // 精华:设置第0个子控制器对应按钮
    UINavigationController *nav = self.childViewControllers[0];
    nav.tabBarItem.title = @"精华";
    nav.tabBarItem.image = [UIImage imageNamed:@"tabBar_essence_icon"];
    nav.tabBarItem.selectedImage = [UIImage imageWithOriginalImageName:@"tabBar_essence_click_icon"];
    
    // 新帖:1
    UINavigationController *nav1 = self.childViewControllers[1];
    nav1.tabBarItem.title = @"新帖";
    nav1.tabBarItem.image = [UIImage imageNamed:@"tabBar_new_icon"];
    nav1.tabBarItem.selectedImage = [UIImage imageWithOriginalImageName:@"tabBar_new_click_icon"];
    
    // 关注:2
    UINavigationController *nav3 = self.childViewControllers[2];
    nav3.tabBarItem.title = @"关注";
    nav3.tabBarItem.image = [UIImage imageNamed:@"tabBar_friendTrends_icon"];
    nav3.tabBarItem.selectedImage = [UIImage imageWithOriginalImageName:@"tabBar_friendTrends_click_icon"];
    
    // 我:3
    UINavigationController *nav4 = self.childViewControllers[3];
    nav4.tabBarItem.title = @"我";
    nav4.tabBarItem.image = [UIImage imageNamed:@"tabBar_me_icon"];
    nav4.tabBarItem.selectedImage = [UIImage imageWithOriginalImageName:@"tabBar_me_click_icon"];
}

#pragma mark - 一.添加所有子控制器
- (void)setupAllChildViewController
{
    // 精华
    XMGEssenceViewController *essence = [[XMGEssenceViewController alloc] init];
    // 创建导航控制器
    XMGNavigationController *nav = [[XMGNavigationController alloc] initWithRootViewController:essence];
    // initWithRootViewController-> Push(vc)
    [self addChildViewController:nav];
    
    // 新帖
    XMGNewViewController *new = [[XMGNewViewController alloc] init];
    // 创建导航控制器
    XMGNavigationController *nav1 = [[XMGNavigationController alloc] initWithRootViewController:new];
    // initWithRootViewController-> Push(vc)
    [self addChildViewController:nav1];

    // 关注
    XMGFriendTrendViewController *friendTrend = [[XMGFriendTrendViewController alloc] init];
    // init -> initWithNibName
    // 创建导航控制器
    XMGNavigationController *nav3 = [[XMGNavigationController alloc] initWithRootViewController:friendTrend];
    // initWithRootViewController-> Push(vc)
    [self addChildViewController:nav3];
    
    // 我
    // 加载storyboard文件
    UIStoryboard *storyboard = [UIStoryboard storyboardWithName:NSStringFromClass([XMGMeViewController class]) bundle:nil];
    // 加载storyboard描述的控制器,加载箭头指向
    XMGMeViewController *me = [storyboard instantiateInitialViewController];
    // 创建导航控制器
    XMGNavigationController *nav4 = [[XMGNavigationController alloc] initWithRootViewController:me];
    // initWithRootViewController-> Push(vc)
    [self addChildViewController:nav4];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
