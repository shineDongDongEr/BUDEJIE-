//
//  XMGEssenceViewController.m
//  01-BuDeJie
//
//  Created by 1 on 15/12/31.
//  Copyright © 2015年 小码哥. All rights reserved.
//

#import "XMGEssenceViewController.h"
#import "UITextField+Placeholder.h"
#import "UIColor+Hex.h"
#import "XMGTitleButton.h"
#import "XMGAllViewController.h"
#import "XMGVideoViewController.h"
#import "XMGVoiceViewController.h"
#import "XMGPictureViewController.h"
#import "XMGWordViewController.h"
#import "XMGSubTagViewController.h"

@interface XMGEssenceViewController () <UIScrollViewDelegate>
/** 标题栏 */
@property (nonatomic, weak) UIView *titlesView;
/** 用来存放所有子控制器view的scrollView */
@property (nonatomic, weak) UIScrollView *scrollView;
/** 下划线 */
@property (nonatomic, weak) UIView *underline;
/** 被点击的按钮 */
@property (nonatomic, weak) XMGTitleButton *clickedTitleButton;
@end

@implementation XMGEssenceViewController

#pragma mark - 初始化
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    self.view.backgroundColor = XMGColor(arc4random_uniform(256), arc4random_uniform(256), arc4random_uniform(256));
    
    // 设置导航条
    [self setupNavBar];
    
    // scrollView
    [self setupScrollView];
    
    // 标题栏
    [self setupTitlesView];
    
    // 初始化子控制器
    [self setupChildVcs];
}

/**
 *  初始化子控制器
 */
- (void)setupChildVcs
{
    [self addChildViewController:[[XMGVoiceViewController alloc] init]];
    [self addChildViewController:[[XMGAllViewController alloc] init]];
    [self addChildViewController:[[XMGVideoViewController alloc] init]];
    [self addChildViewController:[[XMGPictureViewController alloc] init]];
    [self addChildViewController:[[XMGWordViewController alloc] init]];
    
    // 内容大小
    self.scrollView.contentSize = CGSizeMake(self.childViewControllers.count * self.scrollView.xmg_width, 0);
    // 不要自动调整scrollView的内边距
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    // 默认添加第0个子控制器view到scrollView
    [self addChildVcViewIntoScrollView:0];
}

/**
 *  scrollView
 */
- (void)setupScrollView
{
    UIScrollView *scrollView = [[UIScrollView alloc] init];
    scrollView.frame = self.view.bounds;
    scrollView.pagingEnabled = YES;
    scrollView.delegate = self;
    scrollView.showsHorizontalScrollIndicator = NO;
    scrollView.showsVerticalScrollIndicator = NO;
    scrollView.backgroundColor = XMGRandomColor;
    [scrollView addSubview:[[UISwitch alloc] init]];
    [self.view addSubview:scrollView];
    self.scrollView = scrollView;
}

/**
 *  标题栏
 */
- (void)setupTitlesView
{
    UIView *titlesView = [[UIView alloc] init];
    titlesView.backgroundColor = [[UIColor whiteColor] colorWithAlphaComponent:0.5];
    titlesView.frame = CGRectMake(0, XMGNavMaxY, self.view.xmg_width, XMGTitlesH);
    [self.view addSubview:titlesView];
    self.titlesView = titlesView;
    
    // 标题按钮
    [self setupTitleButtons];
    
    // 下划线
    [self setupUnderline];
}

/**
 *  标题按钮
 */
- (void)setupTitleButtons
{
    // 文字
    NSArray *titles = @[@"声音", @"全部", @"视频", @"图片", @"段子"];
    NSUInteger count = titles.count;
    
    // 标题的宽高
    CGFloat titleW = self.titlesView.xmg_width / count;
    CGFloat titleH = self.titlesView.xmg_height;
    
    for (NSUInteger i = 0; i < count; i++) {
        // 创建添加
        XMGTitleButton *titleButton = [XMGTitleButton buttonWithType:UIButtonTypeCustom];
        titleButton.tag = i;
        [titleButton addTarget:self action:@selector(titleClick:) forControlEvents:UIControlEventTouchUpInside];
        [self.titlesView addSubview:titleButton];
        
        // frame
        CGFloat titleX = titleW * i;
        titleButton.frame = CGRectMake(titleX, 0, titleW, titleH);
        
        // 数据
        [titleButton setTitle:titles[i] forState:UIControlStateNormal];
    }
}

/**
 *  下划线
 */
- (void)setupUnderline
{
    // 第一个按钮
    XMGTitleButton *firstTitleButton = self.titlesView.subviews.firstObject;
    
    // 下划线
    UIView *underline = [[UIView alloc] init];
    underline.backgroundColor = [firstTitleButton titleColorForState:UIControlStateSelected];
    underline.xmg_height = 2;
    underline.xmg_y = self.titlesView.xmg_height - underline.xmg_height;
    [self.titlesView addSubview:underline];
    self.underline = underline;
    
    // 默认选中第一个按钮
    // 改变按钮状态
    firstTitleButton.selected = YES; // UIControlStateSelected
    self.clickedTitleButton = firstTitleButton;
    
    [firstTitleButton.titleLabel sizeToFit]; // 主动根据文字内容计算按钮内部label的大小
    // 下划线宽度 == 按钮内部文字的宽度
    underline.xmg_width = firstTitleButton.titleLabel.xmg_width + XMGMargin;
    // 下划线中心点x
    underline.xmg_centerX = firstTitleButton.xmg_centerX;
}

// 设置导航条
- (void)setupNavBar
{
    // UINavigationItem:决定导航条内容
    // UIBarButtonItem:决定导航条上按钮的内容
    
    // left
    self.navigationItem.leftBarButtonItem = [UIBarButtonItem itemWithImage:[UIImage imageNamed:@"MainTagSubIcon"] highImage:[UIImage imageNamed:@"MainTagSubIconClick"] target:self action:@selector(clickSubTag)];
    
    // titleView
    self.navigationItem.titleView = [[UIImageView alloc] initWithImage:[UIImage imageNamed:@"MainTitle"]];
}

// 点击标签按钮
- (void)clickSubTag
{
    // 创建子标签界面
    XMGSubTagViewController *subTag = [[XMGSubTagViewController alloc] init];
    
    // 跳转到推荐标签界面
    [self.navigationController pushViewController:subTag animated:YES];
}

#pragma mark - 监听
- (void)game
{
    XMGFunc
}

/**
 *  监听标题按钮点击
 */
- (void)titleClick:(XMGTitleButton *)titleButton
{
    // 监听重复点击
    if (self.clickedTitleButton == titleButton) {
        [[NSNotificationCenter defaultCenter] postNotificationName:XMGTitleButtonDidRepeatClickNotification object:nil];
    }
    
    // 改变按钮状态
    self.clickedTitleButton.selected = NO; // UIControlStateNormal
    titleButton.selected = YES; // UIControlStateSelected
    self.clickedTitleButton = titleButton;
    
    // 按钮的索引
    NSInteger index = titleButton.tag;
    
    // 移动下划线
    [UIView animateWithDuration:0.25 animations:^{
        // 宽度 == 按钮内部文字的宽度
        self.underline.xmg_width = titleButton.titleLabel.xmg_width + XMGMargin;
        
        // 中心点x
        self.underline.xmg_centerX = titleButton.xmg_centerX;
        
        // 滚动scrollView到最新的子控制器界面(这里只需要水平滚动, 只改contentOffset.x)
        CGPoint offset = self.scrollView.contentOffset;
        offset.x = index * self.scrollView.xmg_width;
        self.scrollView.contentOffset = offset;
    } completion:^(BOOL finished) { // 滚动动画完毕
        // 添加对应的子控制器view到scrollView上面
        [self addChildVcViewIntoScrollView:index];
    }];
}

#pragma mark - <UIScrollViewDelegate>
/**
 * scrollView停止滚动的时候调用(结束减速,速度减为0)
 */
- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSUInteger index = scrollView.contentOffset.x / scrollView.xmg_width;
    // 点击对应的按钮
    XMGTitleButton *titleButton = self.titlesView.subviews[index];
    [self titleClick:titleButton];
}

#pragma mark - 其他
/**
 *  添加第index个子控制器view到scrollView中
 */
- (void)addChildVcViewIntoScrollView:(NSInteger)index
{
    // 添加对应的子控制器view到scrollView上面
    UIViewController *childVc = self.childViewControllers[index];
    
    // 如果这个子控制器view已经显示在上面, 就直接返回
    if (childVc.view.superview) return;
    
    [self.scrollView addSubview:childVc.view];
    
    // 子控制器view的frame
    childVc.view.xmg_x = index * self.scrollView.xmg_width;
    childVc.view.xmg_y = 0;
    childVc.view.xmg_width = self.scrollView.xmg_width;
    childVc.view.xmg_height = self.scrollView.xmg_height;
}
@end
